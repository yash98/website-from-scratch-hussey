Images courtesy of:

Carrots by http://www.flickr.com/photos/salim/

Kale by http://www.flickr.com/photos/laurelfan/

Potato by http://www.flickr.com/photos/lindstorm/
